from django.db import models
from django.conf import settings

User = settings.AUTH_USER_MODEL  # usually 'auth.User'

class Activity(models.Model):
    title = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    date = models.DateField()         # date of the activity
    start_time = models.TimeField()
    end_time = models.TimeField()
    capacity = models.PositiveIntegerField(default=20)  # optional
    price = models.DecimalField(max_digits=8, decimal_places=2, default=0.00)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.title} - {self.date}"
'''
class Booking(models.Model):
    parent = models.ForeignKey(User, on_delete=models.CASCADE, related_name='bookings')
    activity = models.ForeignKey(Activity, on_delete=models.CASCADE, related_name='bookings')
    booked_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('parent', 'activity')  # avoid duplicate booking for same activity

    def __str__(self):
        return f"Booking: {self.parent} -> {self.activity}"
'''
class Booking(models.Model):
    parent = models.ForeignKey(User, on_delete=models.CASCADE, related_name='bookings')
    activity = models.ForeignKey(Activity, on_delete=models.CASCADE, related_name='bookings')
    activity_date = models.DateField()
    booked_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('parent', 'activity_date')

    def save(self, *args, **kwargs):
        self.activity_date = self.activity.date
        super().save(*args, **kwargs)
