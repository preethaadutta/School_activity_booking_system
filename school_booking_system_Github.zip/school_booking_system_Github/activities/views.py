from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth import login, logout
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse
from django import forms
from .models import Activity, Booking
from .forms import BookingForm
from django.utils import timezone
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
'''
def activity_list(request):
    activities = Activity.objects.order_by('date','start_time')
    return render(request, 'activities/activity_list.html', {'activities': activities})
'''
'''
def activity_list(request):
    activities = Activity.objects.all()
    return render(request, 'activities/activity_list.html', {'activities': activities})
'''
'''
def activity_list(request):
    activities = Activity.objects.all().order_by('date')

    booked_dates = []

    if request.user.is_authenticated:
        booked_dates = list(
            Booking.objects.filter(parent=request.user)
                           .values_list('activity__date', flat=True)
        )

    return render(request, 'activities/activity_list.html', {
        'activities': activities,
        'booked_dates': booked_dates
    })
'''
def activity_list(request):
    activities = Activity.objects.all().order_by("date")

    booked_ids = []
    if request.user.is_authenticated:
        booked_ids = Booking.objects.filter(parent=request.user).values_list("activity_id", flat=True)

    return render(request, 'activities/activity_list.html', {
        'activities': activities,
        'booked_ids': booked_ids
    })

def activity_detail(request, pk):
    activity = get_object_or_404(Activity, pk=pk)
    return render(request, 'activities/activity_detail.html', {'activity': activity})

@login_required
def book_activity(request, pk):
    activity = get_object_or_404(Activity, pk=pk)
    parent = request.user

    # 1) Prevent same-day multiple bookings (as per assignment "one per day")
    same_day_bookings = Booking.objects.filter(
        parent=parent,
        activity__date=activity.date
    )
    if same_day_bookings.exists():
        # show message or redirect with error
        return render(request, 'activities/booking_failed.html', {
            'reason': 'A booking already exists for this parent on the same day.'
        })

    # 2) Prevent over-capacity if capacity used
    if activity.capacity is not None:
        current_count = activity.bookings.count()
        if current_count >= activity.capacity:
            return render(request, 'activities/booking_failed.html', {
                'reason': 'Activity is full.'
            })

    # create booking
    booking = Booking.objects.create(parent=parent, activity=activity)

    # After creation: redirect to success page or invoice
    return redirect('activities:invoice_pdf', booking_id=booking.id)

# ADMIN VIEWS (simple, require staff user)
def staff_required(user):
    return user.is_staff
# Simple form for admin to add/edit activities
class ActivityForm(forms.ModelForm):
    class Meta:
        model = Activity
        fields = ["title", "description", "date", "start_time", "end_time", "capacity", "price"]

@user_passes_test(staff_required)
def admin_activity_list(request):
    activities = Activity.objects.all().order_by('date')
    return render(request, 'activities/admin_activity_list.html', {'activities': activities})

# ... Add admin_add_activity and admin_edit_activity using simple ModelForm or Django admin


'''
@login_required
def invoice_pdf(request, booking_id):
    booking = get_object_or_404(Booking, id=booking_id, parent=request.user)
    activity = booking.activity

    # Create the HttpResponse object with the appropriate PDF headers.
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="invoice_booking_{booking.id}.pdf"'

    p = canvas.Canvas(response, pagesize=A4)
    width, height = A4

    p.setFont("Helvetica-Bold", 16)
    p.drawString(50, height - 50, "Activity Booking Invoice")

    p.setFont("Helvetica", 12)
    p.drawString(50, height - 90, f"Parent: {request.user.get_full_name() or request.user.username}")
    p.drawString(50, height - 110, f"Activity: {activity.title}")
    p.drawString(50, height - 130, f"Date: {activity.date}")
    p.drawString(50, height - 150, f"Time: {activity.start_time} - {activity.end_time}")
    p.drawString(50, height - 170, f"Price: £{activity.price}")
    p.drawString(50, height - 200, f"Booked at: {booking.booked_at.strftime('%Y-%m-%d %H:%M')}")
'''
@login_required
def invoice_pdf(request, booking_id):
    booking = get_object_or_404(Booking, id=booking_id, parent=request.user)
    activity = booking.activity

    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="invoice_{booking.id}.pdf"'

    p = canvas.Canvas(response, pagesize=A4)
    width, height = A4

    p.setFont("Helvetica-Bold", 16)
    p.drawString(50, height - 50, "Activity Booking Invoice")

    p.setFont("Helvetica", 12)
    p.drawString(50, height - 90, f"Parent: {request.user.username}")
    p.drawString(50, height - 110, f"Activity: {activity.title}")
    p.drawString(50, height - 130, f"Date: {activity.date}")
    p.drawString(50, height - 150, f"Time: {activity.start_time} - {activity.end_time}")
    p.drawString(50, height - 170, f"Price: £{activity.price}")
    p.drawString(50, height - 200, f"Booked at: {booking.booked_at.strftime('%Y-%m-%d %H:%M')}")

    p.showPage()
    p.save()
    return response

# ------------------------------
# ADMIN: ADD ACTIVITY
# ------------------------------
@user_passes_test(staff_required)
def admin_add_activity(request):
    if request.method == "POST":
        form = ActivityForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("activities:admin_activity_list")
    else:
        form = ActivityForm()
    return render(request, "activities/admin_add_activity.html", {"form": form})
# ------------------------------
# ADMIN: EDIT ACTIVITY
# ------------------------------
@user_passes_test(staff_required)
def admin_edit_activity(request, pk):
    activity = get_object_or_404(Activity, pk=pk)

    if request.method == "POST":
        form = ActivityForm(request.POST, instance=activity)
        if form.is_valid():
            form.save()
            return redirect("activities:admin_activity_list")
    else:
        form = ActivityForm(instance=activity)

    return render(request, "activities/admin_edit_activity.html", {"form": form, "activity": activity})

