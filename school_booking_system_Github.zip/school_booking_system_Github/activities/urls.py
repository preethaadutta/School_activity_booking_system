from django.urls import path
from . import views

app_name = 'activities'

urlpatterns = [
    path('', views.activity_list, name='activity_list'),
    path('activity/<int:pk>/', views.activity_detail, name='activity_detail'),
    path('activity/<int:pk>/book/', views.book_activity, name='book_activity'),
    path('invoice/<int:booking_id>/', views.invoice_pdf, name='invoice_pdf'),
    path('admin/activities/', views.admin_activity_list, name='admin_activity_list'),
    path('admin/activities/add/', views.admin_add_activity, name='admin_add_activity'),
    path('admin/activities/<int:pk>/edit/', views.admin_edit_activity, name='admin_edit_activity'),
]
