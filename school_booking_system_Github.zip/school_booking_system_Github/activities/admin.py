from django.contrib import admin
from .models import Activity, Booking

@admin.register(Activity)
class ActivityAdmin(admin.ModelAdmin):
    list_display = ('title', 'date', 'start_time', 'end_time', 'capacity', 'price')
@admin.register(Booking)
class BookingAdmin(admin.ModelAdmin):
    list_display = ('parent', 'activity', 'booked_at')
